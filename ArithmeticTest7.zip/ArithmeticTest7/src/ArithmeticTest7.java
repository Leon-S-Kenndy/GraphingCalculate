import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.*;

public class ArithmeticTest7 extends JFrame implements ActionListener {
	private final String[] str = { 
		"7", "8", "9", "/", 
		"4", "5", "6", "*",
		"1", "2", "3", "-", 
		".", "0", "=", "+"};
    private final String[] str2 = 
    	{ "Start","Retry","Next turn","show his file"};
    private final String[] str1 = 
    	{ "+","-","*","/","r"};                            
    JButton[] buttons = new JButton[str.length];  //buttons for numbers
    JMenuItem[] buttons1 = new JMenuItem[str1.length];
    JButton giveAnswer = new JButton("give answer");         //button for reset
    JButton up[] = new JButton[str2.length];  
    JTextField display = new JTextField("");
    JTextField display1 = new JTextField("答案");
    JTextField answer = new JTextField("");
    JTextField display2 = new JTextField("如有余数，填此"); 
    JTextField answer2 = new JTextField("");
    JTextField user1 = new JTextField("用户名：");
    JTextField user2 = new JTextField("");
    JTextArea file = new JTextArea("");
    JScrollPane File=new JScrollPane(file);
    JTextField numberOfDigit1 = new JTextField("位数：");
    JTextField numberOfDigit2 = new JTextField("");
    JComboBox calculate=new JComboBox();
    

    public ArithmeticTest7() {
    	
        super("Calculator");
		Font font = new Font("Consolas", Font.BOLD, 18);
		// add components
		JPanel pnlHead = new JPanel(new BorderLayout());
		JPanel pnlHeadUp = new JPanel(new GridLayout(1,5));
		JPanel pnlBodyEast = new JPanel(new GridLayout(3,1));
		JPanel displayArea=new JPanel(new GridLayout(1,5));
		displayArea.add(display);
		displayArea.add(display1);
		displayArea.add(answer);
		displayArea.add(display2);
		displayArea.add(answer2);
		pnlHeadUp.add(user1);
		pnlHeadUp.add(user2);
		pnlHeadUp.add(numberOfDigit1);
		pnlHeadUp.add(numberOfDigit2);
		pnlHeadUp.add(calculate);
		for (int i = 0; i < str1.length; i++) 
		{
            calculate.addItem(str1[i]);
        }
		for (int i = 0; i < str2.length; i++) 
		{

			up[i] = new JButton(str2[i]);
			up[i].setFont(font);
			if(i==0)
				pnlHeadUp.add( up[i]);
			else
				pnlBodyEast.add(up[i]);
		}

        pnlHead.add( displayArea, BorderLayout.CENTER);
        pnlHead.add( giveAnswer, BorderLayout.EAST);
        pnlHead.add( pnlHeadUp, BorderLayout.NORTH);
		display.setFont(font);
		giveAnswer.setFont(font);
		user1.setEnabled(false);
		display.setEnabled(false);
		display1.setEnabled(false);
		display2.setEnabled(false);
		numberOfDigit1.setEnabled(false);
		
        JPanel pnlBody = new JPanel(new BorderLayout());
        pnlBody.add(File,BorderLayout.CENTER);
        pnlBody.add(pnlBodyEast,BorderLayout.EAST);

        setLayout(new BorderLayout());
        add(BorderLayout.NORTH, pnlHead);
        add(BorderLayout.CENTER, pnlBody);
        giveAnswer.addActionListener(this);
        display.addActionListener(this);
        calculate.addActionListener(this);

        for (int i = 0; i < str2.length; i++) 
		{
        	up[i].addActionListener(this);
		}
		// set frame properties
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(680, 800);
        Dimension displaySize = Toolkit.getDefaultToolkit().getScreenSize(); // 获得显示器大小对象  
        Dimension frameSize = getSize();   
        setLocation((displaySize.width - frameSize.width) / 2, (displaySize.height - frameSize.height) / 2);
        setVisible(true);
    }
 
    int o=0;
    int score=0;
	int[] Answer=new int[10];
	int[] Answer2=new int[10];
	int[] b=new int[10];
	int[] n=new int[10];
	int[] m=new int[10];
	String[] c=new String[10];
	String N,M;
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();

		if (source == giveAnswer)
	    {   
			
			String q=answer.getText();
			int a=Integer.parseInt(q);
			if(a==Answer[o])
				score=score+10; 	       	
        	String str = null;
        	switch (b[o]) {
			case 1:
				str=String.format("%-18s%-18s%-18s%-18s\r\n",n[o]+"+"+m[o]+"=","用户答案:"+a,"标准答案:"+Answer[o],"目前得分:"+score);
				break;
			case 2:
				if(n[o]<m[o])
					str=String.format("%-18s%-18s%-18s%-18s\r\n",m[o]+"-"+n[o]+"=","用户答案:"+a,"标准答案:"+Answer[o],"目前得分:"+score);
				if(n[o]>=m[o])
					str=String.format("%-18s%-18s%-18s%-18s\r\n",n[o]+"-"+m[o]+"=","用户答案:"+a,"标准答案:"+Answer[o],"目前得分:"+score);	
				break;
			case 3:
				str=String.format("%-18s%-18s%-18s%-18s\r\n",n[o]+"*"+m[o]+"=","用户答案:"+a,"标准答案:"+Answer[o],"目前得分:"+score);
				break;
			case 4:
				if(n[o]<m[o])
				{
					str=String.format("%-18s%-18s%-18s%-18s\r\n",m[o]+"/"+n[o]+"=","用户答案:"+a,"标准答案:"+Answer[o],"目前得分:"+score);
									
				}	
				if(n[o]>=m[o])
				{
					str=String.format("%-18s%-18s%-18s%-18s\r\n",n[o]+"/"+m[o]+"=","用户答案:"+a,"标准答案:"+Answer[o],"目前得分:"+score);
				}
				break;
			}
             		
        	 file.setText(file.getText()+str);
        	 
        	if(o<10)
    		{
        		o=o+1;
        		if(o!=10)
		    	{display.setText(c[o]);
		    	answer.setText("");
		    	answer2.setText("");}
		    }
        	
         		String o=file.getText();
     			File file=new File("E:\\"+user2.getText()+".his");
     			FileWriter fw = null;
     			try {
     				fw = new FileWriter(file);
     			} catch (IOException e1) {
     				e1.printStackTrace();
     			}
         	    try {
     				fw.write(o);
     			} catch (IOException e1) {
     				e1.printStackTrace();
     			}
     		
        	
    	    
        		
	    }
        if (source==up[0]) 
        	CalculateE();
      
        if (source==up[1])
        {
        	CalculateE();
            file.setText("");
            score=0;
            o=0;
        }
        if (source==up[2])
        {
        	CalculateE();
            score=0;
            o=0;
        }
        if (source==up[3])
        {
        	File file1 = new File("E:\\"+user2.getText()+".his");
            BufferedReader reader = null;
            try {
                
                reader = new BufferedReader(new FileReader(file1));
                String tempString = null;
                while ((tempString = reader.readLine()) != null) {                    
                	file.setText(file.getText()+tempString);
                }
                reader.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            } finally {
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e1) {
                    }
                }
            }
        }
        
    }

	
    public void CalculateE()
    {
    	String s=numberOfDigit2.getText();
    	int Number=Integer.parseInt(s);		
		if(calculate.getSelectedItem()=="+")
        {
			for(int i=0;i<10;i++)
				b[i]=1;
        }
		if(calculate.getSelectedItem()=="-")
        {
			for(int i=0;i<10;i++)
				b[i]=2;
        }
		if(calculate.getSelectedItem()=="*")
        {
			for(int i=0;i<10;i++)
				b[i]=3;
        }
		if(calculate.getSelectedItem()=="/")
        {
			for(int i=0;i<10;i++)
				b[i]=4;
        }
		if(calculate.getSelectedItem()=="r")
        {
			for(int i=0;i<10;i++)
				b[i]=(int)(Math.random()*4)+1;
        }
		for(int i=0;i<10;i++)
		{
			n[i]=(int)(Math.random()*(Math.pow(10, Number)-1))+1;
    		m[i]=(int)(Math.random()*(Math.pow(10, Number)-1))+1;
    		N=String.valueOf(n[i]);
    		M=String.valueOf(m[i]);
			switch (b[i]) {
			case 1:
				c[i]=N+"+"+M+"=";
				Answer[i]=n[i]+m[i];
				break;
			case 2:
				if(n[i]<m[i])
					c[i]=M+"-"+N+"=";
				if(n[i]>=m[i])
					c[i]=N+"-"+M+"=";
				Answer[i]=Math.abs(m[i]-n[i]);	
				break;
			case 3:
				Answer[i]=n[i]*m[i];
				c[i]=N+"*"+M+"=";
				break;
			case 4:
				if(n[i]<m[i])
				{
					c[i]=M+"/"+N+"=";
					Answer[i]=m[i]/n[i];
					Answer2[i]=m[i]%n[i];				
				}	
				if(n[i]>=m[i])
				{
					c[i]=N+"/"+M+"=";
					Answer[i]=n[i]/m[i];
					Answer2[i]=n[i]%m[i];
				}
				break;
			}
		}
		display.setText(c[0]);
    }
    
    
   

	public static void main(String[] args) {
		SwingUtilities.invokeLater(()->{
			new ArithmeticTest7();
		});
    }
}
